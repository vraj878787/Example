class CustomFooter extends HTMLElement {
    connectedCallback() {
        this.attachShadow({ mode: 'open' });
        this.shadowRoot.innerHTML = `
            <style>
                :host {
                    display: block;
                    background-color: #111827;
                    color: rgba(255, 255, 255, 0.7);
                    padding: 4rem 0 2rem;
                }
                
                .container {
                    max-width: 1280px;
                    margin: 0 auto;
                    padding: 0 1rem;
                }
                
                .footer-grid {
                    display: grid;
                    grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
                    gap: 3rem;
                    margin-bottom: 3rem;
                }
                
                .footer-logo {
                    font-size: 1.5rem;
                    font-weight: 800;
                    margin-bottom: 1rem;
                }
                
                .footer-logo span {
                    background: linear-gradient(to right, #6366f1, #f59e0b);
                    -webkit-background-clip: text;
                    -webkit-text-fill-color: transparent;
                }
                
                .footer-description {
                    margin-bottom: 1.5rem;
                    line-height: 1.6;
                }
                
                .social-links {
                    display: flex;
                    gap: 1rem;
                }
                
                .social-links a {
                    color: rgba(255, 255, 255, 0.7);
                    transition: color 0.2s;
                }
                
                .social-links a:hover {
                    color: #6366f1;
                }
                
                .footer-title {
                    font-size: 1.125rem;
                    font-weight: 600;
                    color: white;
                    margin-bottom: 1.5rem;
                }
                
                .footer-links {
                    display: flex;
                    flex-direction: column;
                    gap: 0.75rem;
                }
                
                .footer-links a {
                    color: rgba(255, 255, 255, 0.7);
                    transition: color 0.2s;
                    text-decoration: none;
                }
                
                .footer-links a:hover {
                    color: #6366f1;
                }
                
                .footer-bottom {
                    border-top: 1px solid rgba(255, 255, 255, 0.1);
                    padding-top: 2rem;
                    text-align: center;
                }
                
                @media (max-width: 768px) {
                    .footer-grid {
                        grid-template-columns: 1fr;
                    }
                }
            </style>
            
            <div class="container">
                <div class="footer-grid">
                    <div>
                        <div class="footer-logo">
                            <span>NexusVortex</span>
                        </div>
                        <p class="footer-description">
                            Digital alchemists transforming brands through strategic marketing and innovative solutions.
                        </p>
                        <div class="social-links">
                            <a href="#" aria-label="Twitter"><i data-feather="twitter"></i></a>
                            <a href="#" aria-label="Instagram"><i data-feather="instagram"></i></a>
                            <a href="#" aria-label="LinkedIn"><i data-feather="linkedin"></i></a>
                            <a href="#" aria-label="Facebook"><i data-feather="facebook"></i></a>
                        </div>
                    </div>
                    
                    <div>
                        <h3 class="footer-title">Services</h3>
                        <div class="footer-links">
                            <a href="#">Copywriting</a>
                            <a href="#">Social Strategy</a>
                            <a href="#">SEO Optimization</a>
                            <a href="#">Workflow Automation</a>
                        </div>
                    </div>
                    
                    <div>
                        <h3 class="footer-title">Company</h3>
                        <div class="footer-links">
                            <a href="#">About Us</a>
                            <a href="#">Case Studies</a>
                            <a href="#">Careers</a>
                            <a href="#">Contact</a>
                        </div>
                    </div>
                    
                    <div>
                        <h3 class="footer-title">Legal</h3>
                        <div class="footer-links">
                            <a href="#">Privacy Policy</a>
                            <a href="#">Terms of Service</a>
                            <a href="#">Cookie Policy</a>
                        </div>
                    </div>
                </div>
                
                <div class="footer-bottom">
                    <p>&copy; ${new Date().getFullYear()} NexusVortex. All rights reserved.</p>
                </div>
            </div>
        `;
        
        // Initialize feather icons
        if (window.feather) {
            window.feather.replace({ class: 'feather', width: 20, height: 20 });
        }
    }
}

customElements.define('custom-footer', CustomFooter);