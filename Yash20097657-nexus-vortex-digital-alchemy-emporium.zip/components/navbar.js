class CustomNavbar extends HTMLElement {
    connectedCallback() {
        this.attachShadow({ mode: 'open' });
        this.shadowRoot.innerHTML = `
            <style>
                :host {
                    display: block;
                    position: fixed;
                    top: 0;
                    left: 0;
                    right: 0;
                    z-index: 1000;
                    backdrop-filter: blur(10px);
                    background-color: rgba(17, 24, 39, 0.8);
                    border-bottom: 1px solid rgba(255, 255, 255, 0.05);
                }
                
                .container {
                    max-width: 1280px;
                    margin: 0 auto;
                    padding: 0 1rem;
                    display: flex;
                    justify-content: space-between;
                    align-items: center;
                    height: 5rem;
                }
                
                .logo {
                    font-weight: 800;
                    font-size: 1.5rem;
                    color: white;
                    display: flex;
                    align-items: center;
                }
                
                .logo span {
                    background: linear-gradient(to right, #6366f1, #f59e0b);
                    -webkit-background-clip: text;
                    -webkit-text-fill-color: transparent;
                }
                
                .nav-links {
                    display: flex;
                    gap: 2rem;
                }
                
                .nav-links a {
                    color: rgba(255, 255, 255, 0.8);
                    font-weight: 500;
                    transition: color 0.2s;
                    text-decoration: none;
                }
                
                .nav-links a:hover {
                    color: #6366f1;
                }
                
                .mobile-menu-btn {
                    display: none;
                    background: none;
                    border: none;
                    color: white;
                    cursor: pointer;
                }
                
                .cta-btn {
                    background: linear-gradient(to right, #6366f1, #4f46e5);
                    color: white;
                    padding: 0.5rem 1.5rem;
                    border-radius: 9999px;
                    font-weight: 500;
                    transition: transform 0.2s, box-shadow 0.2s;
                }
                
                .cta-btn:hover {
                    transform: translateY(-2px);
                    box-shadow: 0 4px 15px rgba(99, 102, 241, 0.3);
                }
                
                @media (max-width: 768px) {
                    .nav-links {
                        display: none;
                    }
                    
                    .mobile-menu-btn {
                        display: block;
                    }
                }
            </style>
            
            <div class="container">
                <a href="/" class="logo">
                    <span>NexusVortex</span>
                </a>
                <div class="nav-links">
                    <a href="#services">Services</a>
                    <a href="#results">Results</a>
                    <a href="#testimonials">Testimonials</a>
                    <a href="#contact">Contact</a>
                    <a href="#contact" class="cta-btn">Get Started</a>
</div>
                
                <button class="mobile-menu-btn">
                    <i data-feather="menu"></i>
                </button>
            </div>
        `;
        
        // Initialize feather icons
        if (window.feather) {
            window.feather.replace({ class: 'feather', width: 24, height: 24 });
        }
    }
}

customElements.define('custom-navbar', CustomNavbar);